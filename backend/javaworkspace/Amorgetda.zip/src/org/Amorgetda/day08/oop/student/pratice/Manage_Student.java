package org.Amorgetda.day08.oop.student.pratice;

public class Manage_Student {

}
