package org.Amorgetda.day05.dimarray.exercise;

public class Run {
	public static void main(String[] args) {
		Exercise_DimArray ex = new Exercise_DimArray();
		ex.practice4();
	}

}
