package org.Amorgetda.day10.oop.abstractex.exercise;

public abstract class Calculator {
	public abstract int add (int a, int b);
	public abstract int substract (int a, int b);
	public abstract double average (int [] a);
}
