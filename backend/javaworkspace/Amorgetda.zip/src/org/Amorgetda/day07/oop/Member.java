package org.Amorgetda.day07.oop;

import java.util.Scanner;

public class Member {
	public static void main (String [] args) {
		
	}
	
	// 멤버변수 (필드)
	public String name;
	char gender;
	public int age;
	String education;
	long salary;
	public String job;
	String property;
	//	집 1채, 자동차 1대 -> String
	//	5,000,000 -> long 
	String phone; // 01012345678
	String address; 
	boolean singleOrNodivoceYN; // Yes or No
	String chidren; // 1남 1여, 아들1, 딸1
	
	
	// 생성자
	public Member () {} 
	
	//멤버메소드(메소드)
	//public void registerMember () {}
	public void doheart () {}
	public void	sendMessage () {}
	public void doPromise () {}

}