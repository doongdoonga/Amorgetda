package org.Amorgetda.day07.oop.exercise;

public class Rectangle {
		// 너비와 높이를 입력받아
		//사각형의 넓이를 출력하는 클래스를 만드시오
		
	
		
		
		public int w;
		public int h;
		
		
		public int ga() {
			return w*h;
		}
}
