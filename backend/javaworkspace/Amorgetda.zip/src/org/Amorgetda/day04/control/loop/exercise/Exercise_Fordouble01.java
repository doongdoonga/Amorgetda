package org.Amorgetda.day04.control.loop.exercise;

public class Exercise_Fordouble01 {
	
	public static void main(String [] args) {
		// *
		// **
		// ***
		// ****
		// *****
		// ******
		
		int n = 1;
		for(int i = 1; i <= 6; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
			n++;
		}
		
		
		
		
		
		
		//System.out.print("*");
		//System.out.println();
	}
}