package org.Amorgetda.day04.array.practice;

public class Run {

}
