package org.Amorgetda.day04.array.practice;

public class Exercise_Array10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
