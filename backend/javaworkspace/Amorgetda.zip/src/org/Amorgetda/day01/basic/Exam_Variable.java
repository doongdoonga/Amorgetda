package org.Amorgetda.day01.basic;

public class Exam_Variable {

	public static void main(String[] args) {
		/*
		 * 숫자(정수, 실수), 문자, 문자열
		 * 자바는 타입을 정해놓고 정해진 데이터로 초기화해야함.
		 * 다르면 Type mismatch : cannot convert from A
		 */
		int a = 3;
		char b = 'B';
		String c = "ABC";
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);

	}

}
