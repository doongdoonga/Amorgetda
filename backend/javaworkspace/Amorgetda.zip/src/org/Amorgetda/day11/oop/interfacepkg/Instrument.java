package org.Amorgetda.day11.oop.interfacepkg;

public interface Instrument {
	public abstract void play();
}
