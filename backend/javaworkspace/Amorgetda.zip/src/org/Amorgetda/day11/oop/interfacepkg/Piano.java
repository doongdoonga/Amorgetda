package org.Amorgetda.day11.oop.interfacepkg;

public class Piano implements Instrument{

	@Override
	public void play() {
		System.out.println("딩가딩가~");
	}

}
