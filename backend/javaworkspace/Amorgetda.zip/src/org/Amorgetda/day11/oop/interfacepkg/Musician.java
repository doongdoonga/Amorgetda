package org.Amorgetda.day11.oop.interfacepkg;

public class Musician {
	
	public void play(Drum drum) {
		System.out.println("두둥탁");
	}
	
	public void play(Guitar guitar) {
		System.out.println("딩가딩가~");
	}
	
	public void play(Piano piano) {
		System.out.println("딩가딩가~");
	}

}
