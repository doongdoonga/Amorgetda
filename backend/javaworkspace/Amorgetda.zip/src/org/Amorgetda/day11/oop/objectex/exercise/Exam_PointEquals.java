package org.Amorgetda.day11.oop.objectex.exercise;

public class Exam_PointEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
