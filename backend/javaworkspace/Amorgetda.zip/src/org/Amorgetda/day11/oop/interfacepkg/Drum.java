package org.Amorgetda.day11.oop.interfacepkg;

public class Drum implements Instrument{

	@Override
	public void play() {
		System.out.println("두둥탁");
	}

}
