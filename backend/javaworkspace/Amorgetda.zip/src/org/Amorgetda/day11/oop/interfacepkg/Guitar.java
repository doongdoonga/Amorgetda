package org.Amorgetda.day11.oop.interfacepkg;

public class Guitar implements Instrument{

	@Override
	public void play() {
		System.out.println("딩가딩가~");
	}

}
