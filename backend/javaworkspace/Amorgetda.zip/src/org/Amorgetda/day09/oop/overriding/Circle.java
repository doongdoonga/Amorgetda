package org.Amorgetda.day09.oop.overriding;

public class Circle extends Shape {
	// @Override // <- 생략가능
	public void draw() {
		System.out.println("Circle");
	}
}
