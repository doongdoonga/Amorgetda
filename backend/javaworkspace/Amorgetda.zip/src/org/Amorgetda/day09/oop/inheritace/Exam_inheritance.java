package org.Amorgetda.day09.oop.inheritace;

import org.Amorgetda.day09.oop.inheritace.point.ColorPoint;

public class Exam_inheritance {

	public static void main(String[] args) {
		
		ColorPoint cp = new ColorPoint(10, 23, "green");
		cp.showColorPoint();
		
		
//		ColorPoint cp = new ColorPoint();
//		cp.setX(5);
//		cp.setY(7);
//		cp.showPoint();
	}
}
