package org.Amorgetda.day09.oop.overriding;

public class Shape {
	public void draw() {
		System.out.println("Shape");
	}
}
