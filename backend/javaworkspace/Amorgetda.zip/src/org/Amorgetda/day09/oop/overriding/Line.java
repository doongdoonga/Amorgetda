package org.Amorgetda.day09.oop.overriding;

public class Line extends Shape {
	@Override
	public void draw() {
//		super.draw();
		System.out.println("Line");
	}
}
