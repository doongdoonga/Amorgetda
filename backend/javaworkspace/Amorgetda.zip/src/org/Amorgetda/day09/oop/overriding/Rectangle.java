package org.Amorgetda.day09.oop.overriding;

public class Rectangle extends Shape {
	@Override
	public void draw() {
		//		super.draw();
		System.out.println("Rectangle");
	}
}
