package org.Amorgetda.day03.control.loop;

public class Exam_While {

	public static void main(String[] args) {
		// 2. While문
		// 문법
		// 초기식
		// while(조건식) { 실행문장; 증가식; }
		int i = 0;
		while(i < 10) {
			System.out.print(i);
			i++;
		}
	}

}
