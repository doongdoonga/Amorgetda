package org.Amorgetda.day03.control.loop;

public class Exam_for {

	public static void main(String[] args) {
		// 반복문
		// 실행문장을 원하는 횟수만큼 반복해줌
		// 문법
		// for(초기식 ; 조건식 ; 증감식) { 실행문장;}
		
		//int i; <- 외부에서 변수를 선언할 수도 있다.
		for(int i = 0; i < 10; i++) {
			System.out.print(i);
		}
		
		for(int i = 0; i < 10; i++ ) {
			System.out.print(i);
		}
		
//		System.out.print(1);
//		System.out.print(2);
//		System.out.print(3);
//		System.out.print(4);
//		System.out.print(5);
//		System.out.print(6);
//		System.out.print(7);
//		System.out.print(8);
//		System.out.print(9);
		
		// "ctrl + f" ->특정 단어 찾기
	}

}
