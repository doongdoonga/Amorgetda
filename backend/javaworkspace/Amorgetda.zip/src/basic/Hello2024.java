package basic;

public class Hello2024 {
	public static void main(String [] args) {
		int n = 2024;
		System.out.print("hello " +n);
	}
}
