package basic;

public class HelloWorld {
	public static void main(String[] args) {
		int n = 2024;
		System.out.println("헬로우 월드");
	}
}
